class Algorithm:
    def __init__(self) -> None:
        pass

    def build(self) -> None:
        pass
    
    def execute(self):
        pass
    