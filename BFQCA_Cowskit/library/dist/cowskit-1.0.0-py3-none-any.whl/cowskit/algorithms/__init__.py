from cowskit.algorithms.algorithm import Algorithm
from cowskit.algorithms.algorithm_qknn import KNearestNeighbors
from cowskit.algorithms.algorithm_genetic import GeneticAlgorithm

