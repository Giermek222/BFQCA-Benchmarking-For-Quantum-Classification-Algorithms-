from cowskit.datasets.dataset import Dataset
from cowskit.datasets.dataset_iris import IrisDataset
from cowskit.datasets.dataset_lines import LinesDataset
from cowskit.datasets.dataset_diabetes import DiabetesDataset
from cowskit.datasets.dataset_palmer_penguin import PalmerPenguinDataset
