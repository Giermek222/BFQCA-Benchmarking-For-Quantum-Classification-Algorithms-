from cowskit.datasets.dataset import Dataset
from cowskit.datasets.dataset_iris import IrisDataset
from cowskit.datasets.dataset_lines import LinesDataset
