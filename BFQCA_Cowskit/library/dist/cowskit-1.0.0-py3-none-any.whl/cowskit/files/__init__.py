import os

DATASET_PATH = os.path.realpath(os.path.dirname(__file__)) + "/"
IRIS_DATASET = DATASET_PATH + "iris.dataset"
PENGUINS_DATASET = DATASET_PATH + "penguins.dataset"
DIABETES_DATASET = DATASET_PATH + "diabetes.dataset"
