## SHAPES

SHAPE_2D = 3 # 2D + input count
SHAPE_3D = 4 # 3D + input count

## QUBITS

MAX_QUBITS = 32