## SHAPES

SHAPE_0D = 1 # input_count vector of values (binary predictions)
SHAPE_1D = 2 # 1D + input_count
SHAPE_2D = 3 # 2D + input count
SHAPE_3D = 4 # 3D + input count

## QUBITS
MAX_QUBITS = 32